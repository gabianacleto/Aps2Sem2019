
package view;
import java.awt.Color;

public class NiveisT4 extends javax.swing.JFrame {

    public NiveisT4() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblquiz1 = new javax.swing.JLabel();
        lblNivel1 = new javax.swing.JLabel();
        lblNivel2 = new javax.swing.JLabel();
        lblNivel3 = new javax.swing.JLabel();
        LblN3 = new javax.swing.JLabel();
        lblclic = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(184, 255, 127));

        lblquiz1.setFont(new java.awt.Font("Candara", 3, 36)); // NOI18N
        lblquiz1.setForeground(new java.awt.Color(0, 51, 0));
        lblquiz1.setText("Quiz");

        lblNivel1.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        lblNivel1.setText("Nível 1");
        lblNivel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblNivel1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblNivel1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblNivel1MouseExited(evt);
            }
        });

        lblNivel2.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        lblNivel2.setText("Nível 2");
        lblNivel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblNivel2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblNivel2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblNivel2MouseExited(evt);
            }
        });

        lblNivel3.setText("Nível 3");

        LblN3.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        LblN3.setText("Nível 3");
        LblN3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LblN3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                LblN3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                LblN3MouseExited(evt);
            }
        });

        lblclic.setFont(new java.awt.Font("Candara", 0, 14)); // NOI18N
        lblclic.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblclic.setText("Clique no nível para começar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblNivel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(lblquiz1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblNivel1)
                        .addGap(39, 39, 39)
                        .addComponent(lblNivel2)
                        .addGap(30, 30, 30)
                        .addComponent(LblN3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(lblclic, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblquiz1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblclic)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNivel1)
                    .addComponent(lblNivel2)
                    .addComponent(LblN3))
                .addGap(51, 51, 51)
                .addComponent(lblNivel3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblNivel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNivel1MouseClicked
        new Nivel1Q1().setVisible(true);
    }//GEN-LAST:event_lblNivel1MouseClicked

    private void lblNivel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNivel1MouseEntered
        lblNivel1.setForeground(Color.GREEN);
    }//GEN-LAST:event_lblNivel1MouseEntered

    private void lblNivel1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNivel1MouseExited
        lblNivel1.setForeground(Color.BLACK);
    }//GEN-LAST:event_lblNivel1MouseExited

    private void lblNivel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNivel2MouseClicked
        new Nivel2Q1().setVisible(true);
    }//GEN-LAST:event_lblNivel2MouseClicked

    private void lblNivel2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNivel2MouseEntered
        lblNivel2.setForeground(Color.GREEN);
    }//GEN-LAST:event_lblNivel2MouseEntered

    private void lblNivel2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNivel2MouseExited
        lblNivel2.setForeground(Color.BLACK);
    }//GEN-LAST:event_lblNivel2MouseExited

    private void LblN3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LblN3MouseEntered
       LblN3.setForeground(Color.GREEN);  
    }//GEN-LAST:event_LblN3MouseEntered

    private void LblN3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LblN3MouseExited
      LblN3.setForeground(Color.BLACK);  
    }//GEN-LAST:event_LblN3MouseExited

    private void LblN3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LblN3MouseClicked
      new Nivel3Q1().setVisible(true);
    }//GEN-LAST:event_LblN3MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NiveisT4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NiveisT4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NiveisT4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NiveisT4.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NiveisT4().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LblN3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblNivel1;
    private javax.swing.JLabel lblNivel2;
    private javax.swing.JLabel lblNivel3;
    private javax.swing.JLabel lblclic;
    private javax.swing.JLabel lblquiz1;
    // End of variables declaration//GEN-END:variables
}
