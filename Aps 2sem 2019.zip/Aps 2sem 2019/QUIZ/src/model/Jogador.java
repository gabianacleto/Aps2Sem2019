
package model;

public class Jogador {

    private String nome;
    /*private int cont1 = 0;
    private int cont2 = 0;
    private int cont3 = 0;
*/
    public Jogador(String n) {
        this.nome = n;
    }
   /* 
    public void acertouN1() {
      cont1++;
    }
    public void acertouN2(int nivel2){
        cont2++;
    }
    public void acertouN3(int nivel3){
        cont3++;
    }
    */
}